
# fake_log_generator.py
import requests, random, time

URL = "http://127.0.0.1:5000/create-ticket"

logs = [
    "Deployment failed rollback initiated",
    "Network timeout during artifact download",
    "Agent disconnected from runner",
    "Authentication token expired",
    "Invalid config variable detected"
]

while True:
    payload = {
        "project": "DemoProject",
        "pipeline": f"Build-{random.randint(100,999)}",
        "log": random.choice(logs)
    }
    requests.post(URL, json=payload)
    print("Injected fake log")
    time.sleep(4)

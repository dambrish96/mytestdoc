
# app_autonomous_demo.py
from flask import Flask, request, jsonify, render_template_string
import os, json, uuid, random
from datetime import datetime

app = Flask(__name__)
DB_FILE = "tickets.json"

if not os.path.exists(DB_FILE):
    with open(DB_FILE, "w") as f:
        json.dump([], f)

ERROR_CATEGORIES = {
    "Authentication": ["auth", "token"],
    "Deployment": ["deploy", "rollback"],
    "Script": ["script", "exception"],
    "Configuration": ["config"],
    "Network": ["timeout", "dns"],
    "Agent": ["agent"]
}

def load_tickets():
    return json.load(open(DB_FILE))

def save_tickets(tickets):
    json.dump(tickets, open(DB_FILE, "w"), indent=2)

def categorize(log):
    for cat, keys in ERROR_CATEGORIES.items():
        if any(k in log.lower() for k in keys):
            return cat
    return "Other"

def remediation_stub(category, confidence):
    if confidence < 0.7:
        return {"action": "Manual review required", "executed": False}
    return {"action": f"Auto-remediation for {category}", "executed": True}

@app.route("/create-ticket", methods=["POST"])
def create_ticket():
    data = request.json
    log = data.get("log", "")
    category = categorize(log)
    confidence = round(random.uniform(0.65, 0.95), 2)

    ticket = {
        "id": str(uuid.uuid4())[:8],
        "pipeline": data.get("pipeline"),
        "project": data.get("project"),
        "category": category,
        "confidence": confidence,
        "remediation": remediation_stub(category, confidence),
        "log": log,
        "created": datetime.utcnow().isoformat()
    }

    tickets = load_tickets()
    tickets.insert(0, ticket)
    save_tickets(tickets)
    return jsonify(ticket), 201

@app.route("/")
def dashboard():
    tickets = load_tickets()
    return render_template_string("""
    <h2>Autonomous DevOps Demo Dashboard</h2>
    {% for t in tickets %}
      <div style='border:1px solid #ccc;padding:10px;margin:10px'>
        <b>{{t.pipeline}}</b> | {{t.category}} | Confidence: {{t.confidence}}<br/>
        AI Action: {{t.remediation.action}}<br/>
        <pre>{{t.log}}</pre>
      </div>
    {% endfor %}
    """, tickets=tickets)

if __name__ == "__main__":
    app.run(debug=True)

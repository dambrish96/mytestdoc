
AUTONOMOUS DEVOPS DEMO – QUICK START

Files:
- app_autonomous_demo.py
- fake_log_generator.py

Steps:
1. python app_autonomous_demo.py
2. Open http://127.0.0.1:5000
3. python fake_log_generator.py

Demo shows:
- AI-style failure categorization
- Confidence-based decisioning
- Auto-remediation stub
